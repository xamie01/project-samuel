import schedule
import time

def bot_task():
    # Add your bot task here
    print("Bot is running...")

# Schedule the bot task to run every 24 hours
schedule.every(24).hours.do(bot_task)

# Keep the script running to execute the scheduled tasks
while True:
    schedule.run_pending()
    time.sleep(1)
