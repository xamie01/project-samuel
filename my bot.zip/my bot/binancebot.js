const Binance = require("binance-api-node").default;
const ta = require("technicalindicators");
const nodemailer = require("nodemailer");
const cron = require("node-cron");
const client = Binance({
  apiKey: "YOUR_API_KEY",
  apiSecret: "YOUR_API_SECRET",
});

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "xamzy37@gmail.com",
    pass: "DebbyBlake101$",
  },
});

const calculateSR = async (symbol, interval) => {
  const candles = await client.candles({ symbol, interval, limit: 192 });
  const closes = candles.map((candle) => parseFloat(candle.close));

  const lows = ta.SMA.calculate({ period: 8, values: closes });
  const highs = ta.SMA.calculate({ period: 8, values: closes });

  let support = lows[0];
  let resistance = highs[0];

  for (let i = 1; i < 192; i++) {
    if (lows[i] < support) {
      support = lows[i];
    }
    if (highs[i] > resistance) {
      resistance = highs[i];
    }
  }

  return { support, resistance };
};

const getMACrossoverSignal = async (symbol, interval) => {
  const candles = await client.candles({ symbol, interval, limit: 240 });
  const closes = candles.map((candle) => parseFloat(candle.close));

  const fastLength = 8;
  const slowLength = 9;
  const signalLength = 9;
  const rsiLength = 14;

  const fastMA = ta.SMA.calculate({ period: fastLength, values: closes });
  const slowMA = ta.SMA.calculate({ period: slowLength, values: closes });

  const macdInput = {
    values: closes,
    fastPeriod: fastLength,
    slowPeriod: slowLength,
    signalPeriod: signalLength,
    SimpleMAOscillator: false,
    SimpleMASignal: false,
  };
  const [macdLine, signalLine] = ta.MACD.calculate(macdInput);
  const rsiValue = ta.RSI.calculate({ period: rsiLength, values: closes });

  const lastFastMA = fastMA[fastMA.length - 1];
  const lastSlowMA = slowMA[slowMA.length - 1];
  const lastMACD = macdLine[macdLine.length - 1];
  const prevMACD = macdLine[macdLine.length - 2];
  const lastRSI = rsiValue[rsiValue.length - 1];
  const prevRSI = rsiValue[rsiValue.length - 2];

  let signal = "";

  if (
    lastFastMA > lastSlowMA &&
    prevMACD <= 0 &&
    lastMACD > 0 &&
    lastRSI > 50 &&
    prevRSI <= 50
  ) {
    signal = "Long";
  } else if (
    lastFastMA < lastSlowMA &&
    prevMACD >= 0 &&
    lastMACD < 0 &&
    lastRSI < 50 &&
    prevRSI >= 50
  ) {
    signal = "Short";
  } else {
    signal = "No available signal";
  }

  return signal;
};

const sendEmail = async (message) => {
  const mailOptions = {
    from: "xamzy37@gmail.com",
    to: "ivanovichmodrich@gmail.com",
    subject: "Trading Signal",
    text: message,
  };

  await transporter.sendMail(mailOptions);
};
const runBot = async () => {
  const exchangeInfo = await client.exchangeInfo();
  const symbols = exchangeInfo.symbols.map((symbol) => symbol.symbol);

  for (const symbol of symbols) {
    const symbolInfo = exchangeInfo.symbols.find((s) => s.symbol === symbol);

    if (
      symbol.endsWith("USDT") &&
      symbolInfo.status === "TRADING" &&
      symbolInfo.quoteAsset === "USDT"
    ) {
      const interval = "4h";
      const { support, resistance } = await calculateSR(symbol, interval);
      const signal = await getMACrossoverSignal(symbol, interval);
      if (signal === "Long") {
        let message = `Trading signal for ${symbol}: LONG
        Support: ${support.toFixed(2)}
        Resistance: ${resistance.toFixed(2)}`;
        sendEmail(message);
      } else if (signal === "Short") {
        const message = `Trading signal for ${symbol}: SHORT
        Support: ${support.toFixed(2)}
        Resistance: ${resistance.toFixed(2)}`;
        sendEmail(message);
      } else {
        console.log(`No trading signal for ${symbol}`);
      }
    }
  }
};
cron.schedule("0 */4 * * *", async () => {
  try {
    console.log("Running bot...");
    await runBot();
    console.log("Bot finished running.");
  } catch (error) {
    console.error("Error running bot:", error);
  }
});

//binance-api-node - A Node.js wrapper for the Binance API. To install, run npm install binance-api-node

//technicalindicators - A library for calculating technical indicators like moving averages, MACD, RSI, and more. To install, run npm install technicalindicators

//nodemailer - A module for sending email from Node.js applications. To install, run npm install nodemailer

//*
